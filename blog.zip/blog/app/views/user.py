from flask import Blueprint, render_template, current_app, request, flash, redirect, url_for, session
from app.forms import RegisterForm, LoginForm,UploadForm,NewpasswodForm,NewemailForm,FindpasswodForm
from app.email import send_mail
from app.models import User
from PIL import Image
from app.extensions import db,photos
from flask_login import login_user,current_user,logout_user,login_required
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer,SignatureExpired
import os
user = Blueprint('user', __name__, url_prefix='/user')

@user.route('/register/', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if request.method == "POST":
        if form.validate_on_submit():
            # 需要根据表单数据创建模型
            u = User(username=form.username.data,
                     password=form.password.data,
                     email=form.email.data)
            # 保存到数据库中
            db.session.add(u)
            # 手动提交
            db.session.commit()
            # 准备token
            s = Serializer(current_app.config['SECRET_KEY'], expires_in=3600)
            token = s.dumps({'id': u.id,'email':None})
            # 发送用户激活邮件
            send_mail('zhanghujihuo', form.email.data,
                      'email/activate.html',
                      username=form.username.data,
                      token=token)
            # 弹出消息提示用户下一步操作
            flash('注册成功,请点击邮件中的连接激活')
            return redirect(url_for('main.index'))
    return render_template('user/register.html', form=form)


# 账户的激活
@user.route('/activate/<token>/')
def activate(token):
    s = Serializer(current_app.config['SECRET_KEY'])
    try:
        data = s.loads(token)
    except SignatureExpired as e:
        flash('token已过期,激活失败')
        return redirect(url_for('main.index'))
    except:
        flash('激活失败')
        return redirect(url_for('main.index'))
    # 根据token中携带的用户信息,在数据库中查询用户
    u = User.query.get(data['id'])
    # 判断是否激活
    if not u.confirmed:
        # 如果没有激活
        u.confirmed = True
        # 再次保存
        db.session.add(u)
        flash('激活成功')
        return redirect(url_for('user.login'))
    if data['email']:
        current_user.email = data['email']
        db.session.add(current_user)
        return redirect(url_for('user.profile'))
    if data['newpassword']:
        u.password = data['newpassword']
        db.session.add(u)
        return redirect(url_for('user.login'))

@user.route('/login/', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if request.method == "POST":
        if form.validate_on_submit():
            u = User.query.filter_by(username=form.username.data).first()
            if u.confirmed:
                # session['username'] = form.username.data
                flash('登录成功')
                login_user(u)
                return redirect(request.args.get('net') or url_for('main.index'))
            flash('请先激活再登录')
    return render_template('user/login.html', form=form)


@user.route('/logout/')
def logout():
    flash('您已退出登录')
    logout_user()
    return redirect(url_for('user.login'))

@user.route('/profile/')
@login_required
def profile():
    return render_template('user/profile.html')

def random_str(length=32):
    import random
    base_str = 'qwertyuioplkjhgfdsazxcvbnm1234567890'
    return ''.join(random.choice(base_str) for i in range(length))

@user.route('/icon/',methods=['GET','POST'])
def icon():
    img_url = None
    form = UploadForm()
    if form.validate_on_submit():
        photo = form.photo.data
        suffix = os.path.splitext(photo.filename)[1]
        # 生成随机文件名
        filename = random_str() + suffix
        photos.save(photo,name=filename)
        # 拼接文件路径名
        pathname = os.path.join(current_app.config['UPLOADED_PHOTOS_DEST'],filename)
        img = Image.open(pathname)
        img.thumbnail((64,64))
        img.save(pathname)
        # 删除原来的图像文件(默认头像不删)
        if current_user.icon != 'default.jpg':
            os.remove(os.path.join(current_app.config['UPLOADED_PHOTOS_DEST'],current_user.icon))
        current_user.icon = filename
        db.session.add(current_user)
        #获取上传文件地址
        img_url=url_for('static',filename='upload/'+ current_user.icon)
    return render_template('user/icon.html',form=form,img_url=img_url)


# 修改密码
@user.route('/newpassword/',methods=['GET','POST'])
def newpassword():
    form = NewpasswodForm()
    if form.validate_on_submit():
        if current_user.verify_password(form.password.data):
            current_user.password =form.newpassword.data
            db.session.add(current_user)
            flash('修改密码成功,请重新登录')
            return redirect(url_for('user.login'))
    return render_template('user/newpassword.html',form=form)
# 修改邮箱
@user.route('/newemail',methods=['GET','POST'])
def newemail():
    form = NewemailForm()
    if form.validate_on_submit():
        # 准备token
        s = Serializer(current_app.config['SECRET_KEY'], expires_in=3600)
        token = s.dumps({'id': current_user.id,'email':form.email.data})
        # 发送用户激活邮件
        send_mail('zhanghujihuo', form.email.data,
                  'email/activate.html',
                  username=current_user.username,
                  token=token)
        # 弹出消息提示用户下一步操作
        flash('修改邮箱成功,请点击邮件中的连接激活')
        return redirect(url_for('main.index'))
    return render_template('user/newemail.html',form=form)

# 找回密码
@user.route('/findpassword/',methods=['GET','POST'])
def findpassword():
    form = FindpasswodForm()
    if form.validate_on_submit():
        u = User.query.filter_by(username=form.username.data).first()
        if u:
            # 准备token
            s = Serializer(current_app.config['SECRET_KEY'], expires_in=3600)
            token = s.dumps({'id': u.id,'email':None, 'newpassword': form.newpassword.data,})
            # 发送用户激活邮件
            send_mail('zhanghujihuo', u.email,
                      'email/activate.html',
                      username=u.username,
                      token=token)
            # 弹出消息提示用户下一步操作
            flash('密码找回成功,请点击邮件中的连接激活后再次登录')
            return redirect(url_for('main.index'))
    return render_template('user/findpassword.html',form=form)

