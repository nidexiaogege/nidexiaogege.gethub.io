from flask import Blueprint,url_for,redirect,render_template,current_app,flash,request
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from app.forms import PostsForm
from app.models import Posts,collections
from app.extensions import db
from flask_login import current_user,login_required

# 创建蓝本
main = Blueprint('main',__name__,url_prefix='/main')

# 添加视图函数
@main.route('/',methods=['GET','POST'])
@login_required
def index():
    form = PostsForm()
    if form.validate_on_submit():
        if not current_user.is_authenticated:
            flash('登录后才可发表')
            return redirect(url_for('user.login'))
        u = current_user._get_current_object()
        p = Posts(content=form.content.data,user=u)
        db.session.add(p)
        flash('发表成功')
        return redirect(url_for('main.index'))
    # posts = Posts.query.filter_by(rid=0).order_by(Posts.timestamp.desc()).all()
    uid = request.args.get('uid',0,int)
    page = request.args.get('page',1,int)
    if uid == 0:
        pagination = Posts.query.filter_by(rid=0).order_by(Posts.timestamp.desc()).\
        paginate(page=page,per_page=3,error_out=False)
    else:
        pagination = Posts.query.filter_by(rid=0).filter_by(uid=uid).order_by(Posts.timestamp.desc()). \
            paginate(page=page, per_page=2, error_out=False)
    posts = pagination.items
    return render_template('main/index.html',form=form,posts=posts,pagination=pagination)

@main.route('/content/',methods=['GET','POST'])
@login_required
def content():
    form = PostsForm()
    pid = request.args.get('pid', 0, int)
    if request.method=='POST':
        if form.validate_on_submit():
            if not current_user.is_authenticated:
                flash('登录后才可发表')
                return redirect(url_for('user.login'))
            u = current_user._get_current_object()
            p = Posts(content=form.content.data,rid=pid, user=u)
            db.session.add(p)
            flash('发表成功')
            return redirect(url_for('main.content',page=1,pid=pid))
    page = request.args.get('page', 1, int)
    post = Posts.query.filter_by(id=pid).first()
    if pid == 0:
        pagination = Posts.query.filter(Posts.rid != 0).order_by(Posts.timestamp.desc()). \
            paginate(page=page, per_page=3, error_out=False)
    else:
        pagination = Posts.query.filter(Posts.rid != 0).filter_by(rid=pid).order_by(Posts.timestamp.desc()). \
            paginate(page=page, per_page=2, error_out=False)
    comments = pagination.items
    return render_template('main/content.html',post=post,form=form,comments=comments,pagination=pagination)


@main.route('/myfavorites/',methods=['GET','POST'])
@login_required
def myfavorites():
    page = request.args.get('page', 1, int)
    pagination = current_user.favorites.order_by(Posts.timestamp.desc()). \
            paginate(page=page, per_page=3, error_out=False)
    posts = pagination.items
    return render_template('main/myfavorites.html', posts=posts, pagination=pagination)

@main.route('/myblog/',methods=['GET','POST'])
@login_required
def myblog():
    uid = current_user.id
    page = request.args.get('page', 1, int)
    # pagination = Posts.query.filter_by(rid=0).filter_by(uid=uid).order_by(Posts.timestamp.desc()).\
        # paginate(page=page,per_page=3,error_out=False)
    pagination = Posts.query.filter_by(rid=0).filter_by(uid=uid).order_by(Posts.timestamp.desc()). \
        paginate(page=page, per_page=2, error_out=False)
    posts = pagination.items
    return render_template('main/myblog.html', posts=posts, pagination=pagination)

# 分页查询 paginate
# 参数:
        # page:当前页码
        # per_page : 每页多少条数据
        # error_out: 当查询有误时是否报错,默认为True
# 返回值
        # Pagination:分页对象,其中包含了分页的所有信息
# Pagination
# 属性:
        # page:当前页码
        # per_page:每页显示多少条,默认为20条
        # pages: 总页数
        # total: 总条数
        # prev_num:上一页的页码
        # next_num:下一页的页码
        # has_prev:是否有上一页
        # has_next:是否有下一页
        # items:当前页的数据
# 方法
        # iter_pages:存放了所有的在分页导航条上的页码,当现实不玩的时候返回None
        # prev:上一页的分页对象
        # next:下一页的分页对象




# 生成token
# @main.route('/generate/')
# def generate():
#     s = Serializer(current_app.config['SECRET_KEY'],expires_in=3600)
#     token = s.dumps({'id':99})
#     return token
#
# # 校验token
# @main.route('/check/<token>/')
# def check(token):
#     s = Serializer(current_app.config['SECRET_KEY'])
#     data = s.loads(token)
#     return str(data['id'])