from flask_wtf import FlaskForm
from wtforms import SubmitField,TextAreaField,StringField,PasswordField
from wtforms.validators import Length,EqualTo,Email,ValidationError,DataRequired
from app.models import User
from flask_wtf.file import FileAllowed,FileRequired,FileField
from app.extensions import photos
from flask import request
# 用户注册表单
class RegisterForm(FlaskForm):
    username = StringField('用户名',validators=[Length(3,10,message='用户名必须在3到10个字符之间')])
    password = PasswordField('密码',validators=[Length(6,16,message='密码长度必须在6到16 个字符之间')])
    confirm = PasswordField('确认密码',validators=[EqualTo('password',message='两次密码不一致')])
    email = StringField('邮箱',validators=[Email(message='邮箱格式不正确')])
    submit = SubmitField('立即注册')

    def validate_username(self, field):
        if User.query.filter_by(username=field.data).all():
            raise ValidationError('用户名重复')
    def validate_email(self, field):
        if User.query.filter_by(email=field.data).all():
            raise ValidationError('邮箱重复')

# 用户登录表单
class LoginForm(FlaskForm):
    username = StringField('用户名',validators=[DataRequired(message='用户名不能为空')])
    password = PasswordField('密码',validators=[DataRequired(message='密码不能为空')])
    submit = SubmitField('立即登录')
    def validate_username(self, field):
        u = User.query.filter_by(username=field.data).all()
        if not u:
            raise ValidationError('用户名不存在')
        else:
            if not u[0].verify_password(self.password.data):
                raise ValidationError('密码错误')


# 上传头像表单
class UploadForm(FlaskForm):
    photo = FileField('头像',validators=[FileRequired('请上传文件'),FileAllowed(photos,message='只能上传图片')])
    submit = SubmitField('提交')
    def validate_photo(self,field):
        if int(request.headers['Content-Length']) > 1024*8:
            raise ValidationError('上传文件太大')
# 添加发表博客的表单
class PostsForm(FlaskForm):

    content = TextAreaField('',render_kw={'placeholder':'这一刻的想法...'},validators=[Length(3,128,message='内容必须在3到128个字符之间')])
    submit = SubmitField('立即发表')




# 修改密码
class NewpasswodForm(FlaskForm):
    password = PasswordField('密码',validators=[DataRequired(message='密码不能为空')])
    newpassword = PasswordField('密码', validators=[Length(6, 16, message='密码长度必须在6到16 个字符之间')])
    confirm = PasswordField('确认密码', validators=[EqualTo('newpassword', message='两次密码不一致')])
    submit = SubmitField('确认修改')

# 修改邮箱
class NewemailForm(FlaskForm):
    email = StringField('邮箱', validators=[Email(message='邮箱格式不正确')])
    submit = SubmitField('确认修改')
# 找回密码

class FindpasswodForm(FlaskForm):
    username = StringField('用户名', validators=[DataRequired(message='用户名不能为空')])
    newpassword = PasswordField('密码', validators=[Length(6, 16, message='密码长度必须在6到16 个字符之间')])
    confirm = PasswordField('确认密码', validators=[EqualTo('newpassword', message='两次密码不一致')])
    submit = SubmitField('找回密码')
